import java.util.ArrayList;
import java.util.List;

public class RepairTicket {

    //FIELDS

    private int ticketId;
    private String title;
    private String description;
    private TicketCategory category;
    private TicketPriority priority;
    private TicketStatus status;
    private Requester requester;
    private Technician technician;
    private List<String> notes = new ArrayList<>() {
        
    };

    //CONSTRUCTORS
    
    public RepairTicket(int ticketId, 
                        String title, 
                        String description, 
                        TicketCategory category, 
                        TicketPriority priority,
                        TicketStatus status,
                        Requester requester,
                        Technician technician,
                        List<String> notes) {
        
        if(ticketId <= 0){
            throw new IllegalArgumentException("Id must be a positive number.");
        }

        if(title == null || title.isBlank()){
            throw new IllegalArgumentException("You must provide a title");
        }

        if(description.length() > 500 || description.length() < 100 || description == null){
            throw new IllegalArgumentException("Description must be between 100 and 500 characters.");
        }

        if(category == null){
            throw new IllegalArgumentException("Category cannot be null");
        }
        if(priority == null){
            throw new IllegalArgumentException("Priority cannot be null");
        }

        if(status == null){
            throw new IllegalArgumentException("Status cannot be null.");
        }

        if(requester == null){
            throw new IllegalArgumentException("Requester cannot be null.");
        }

        if(technician == null){
            throw new IllegalArgumentException("Technician cannot be null");
        }

        this.ticketId = ticketId;
        this.title = title;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = status;
        this.requester = requester;
        this.technician = technician;
        this.notes = notes;
    }

    //GETTERS

    public int getTicketId(){
        return ticketId;
    }

    public String getTitle(){
        return title;
    }

    public String getDescription(){
        return description;
    }

    public TicketCategory getTicketCategory(){
        return category;
    }

    public TicketPriority getTicketPriority(){
        return priority;
    }

    public TicketStatus getTicketStatus(){
        return status;
    }

    public Requester getTicketRequester(){
        return requester;
    }

    public Technician getTechnician(){
        return technician;
    }

    public List<String> getNotes(){
        return notes;
    }

    //METHODS

    public void changeTicketStatus(TicketStatus ticketStatus){
        this.status = ticketStatus;
    }

    public void assignTechnician(Technician technician){
        if(this.status == TicketStatus.CLOSED){
            System.out.println("You cannot modify a closed ticket");
            return;
        }
        this.technician = technician;
    }

    public void assignRequester(Requester requester){
        this.requester = requester;
    }

    public void changeTicketPriority(TicketPriority ticketPriority){
        if(this.status == TicketStatus.CLOSED){
            System.out.println("You cannot modify a closed ticket");
            return;
        }
        this.priority = ticketPriority;
    }

    public boolean isClosed(){
        if(this.status == TicketStatus.CLOSED){
            return true;
        }
        return false;
    }

    public void addNote(String note){
        notes.add(note);
    }
}
