import java.util.List;

public class utils {
    

    public void ListTechnicians(List<Technician> technicians){
        for(Technician tech: technicians){
            System.out.println(tech.getFirstName() + " " + tech.getLastName());
        }
    }

}
