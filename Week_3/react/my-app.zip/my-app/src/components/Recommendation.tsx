import { useEffect, useState } from "react";
import { RecommendationCard } from "./RecommendationCards";
import type { recommendationType } from "./RecommendationCards";
import { Card } from "../ui/Card";


export function Recommendation(){

    const [recommendations, setRecommendations] = useState<recommendationType[]>([]);
    const [loadingStatus, setLoadingStatus] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("smartphones");

    

    const URL:string  = `https://dummyjson.com/products/category/${selectedCategory}`

    useEffect(() =>  {
        setLoadingStatus(true);
        setErrorMessage("");
        
            const fetchData = async () => {
                try{
                    const response = await fetch(URL);
                    if(!response.ok){
                        setErrorMessage(`Data not accessible: ${response.status}`);
                    }
                    else{
                        const jsonData =  await response.json();
                        const data = dataParse(jsonData);
                        setRecommendations(data);

                    }
                }catch(error){
                    setErrorMessage("Failed to fetch");
                }finally{
                    setLoadingStatus(false)
                    
                }
            } 
            fetchData();
    }, [selectedCategory])


    function dataParse(data: {products: recommendationType[]} ){

        const productsArray = data.products;

        return productsArray;
        
    }


    return(
        <>
            {loadingStatus && <p className="px-3 font-bold border rounded-lg">Loading...</p>}
            {!loadingStatus && !errorMessage && recommendations.length > 0 && <p className="font-bold text-blue-700 border w-20 m-3 rounded-lg">Success!</p>}
            {errorMessage && <p className="text-red-600 font-bold border rounded-lg">{errorMessage}</p>}
            {!loadingStatus && !errorMessage && recommendations.length === 0 && <p className="font-bold text-red-900 border round-lg">The results were empty</p>}
            <div>
                <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} className="bg-amber-50 m-3 border p-2 rounded-lg focus:outline-none focus:ring-2">
                    <option value="smartphones">Smartphones</option>
                    <option value="laptops">Laptops</option>
                    <option value="furniture">Furniture</option>
                    <option value="beauty">Beauty</option>
                </select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recommendations.map((rec) => {
                        return(
                            <Card key={rec.id}>
                                <RecommendationCard 
                                    title = {rec.title}
                                    description = {rec.description}
                                    category = {rec.category}
                                    price = {rec.price}
                                />
                            </Card>
                        )})}
            </div>
        </>
    )
}