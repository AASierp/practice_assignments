package com.example.repair_ticket.service;

import com.example.repair_ticket.domain.Technician;
import com.example.repair_ticket.domain.TicketCategory;
import com.example.repair_ticket.domain.TicketPriority;
import com.example.repair_ticket.domain.TicketStatus;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import com.example.repair_ticket.domain.RepairTicket;
import com.example.repair_ticket.domain.Requester;

@Service
public class RepairTicketService {

    private NotificationService notificationService;
    public List<RepairTicket> tickets = new ArrayList<>();

    Technician tech1 = new Technician(1, "bob", "vance", "bob@gmail.com", tickets);

    Requester req1 = new Requester(1, "aaron", "sierp", "aaron@gmail.com");

    RepairTicket repairTicket1 = new RepairTicket(
            1,
            "Virus Removal",
            "Customer's laptop is infected with malware: perform diagnostics and virus removal..",
            TicketCategory.SOFTWARE,
            TicketPriority.HIGH,
            TicketStatus.OPEN,
            req1,
            tech1,
            (new ArrayList<>()));

    RepairTicket repairTicket2 = new RepairTicket(
            2,
            "Bad Power Supply",
            "Clients computer needs a new power supply installed",
            TicketCategory.HARDWARE,
            TicketPriority.LOW,
            TicketStatus.INPROGRESS,
            req1,
            tech1,
            (new ArrayList<>()));

    public RepairTicketService(NotificationService notificationService) {
        this.notificationService = notificationService;
        tickets.add(repairTicket1);
        tickets.add(repairTicket2);
    }

    public void assignTechnicianService(RepairTicket repairTicket, Technician technician) {
        repairTicket.assignTechnician(technician);
        technician.addTickets(repairTicket);

        notificationService.sendNotification(technician.getFirstName() + " " + technician.getLastName()
                + " has been assigned to ticket " + repairTicket.getTicketId() + ", " + "Technician tickets updated");
    }

    public List<RepairTicket> getAllTicketsService() {

        return tickets;
    }

    public RepairTicket getTicketByIdService(int id){

        for(RepairTicket ticket: tickets){
            if (ticket.getTicketId() == id){
                return ticket;
            }

        }
        return null;
    }

    public RepairTicket postTicketService(RepairTicket ticket){
        tickets.add(ticket);
        return ticket;
    }
}
